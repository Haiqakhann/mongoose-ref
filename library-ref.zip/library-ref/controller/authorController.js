import bookdb from "../model/book.js";
import {authordb} from "../model/author.js";


const author = (req,res)=>{
    bookdb.find()
    .then(books => {
        res.render('addauthor.ejs', { books });
    })
    .catch(err => {
        res.status(500).send({
            message: err.message || "some error occur while retrieving users"
        })
    });
}


const addauthor = (req,res)=>{
    if (!req.body) {
        res.status(400).send({ message: "content cannot be empty" })
        return;
    }
    console.log(req.body)
    const author = new authordb({
        author: req.body.author,
        book:req.body.books,
        date:req.body.date
    })
    // save book in database
    author
        .save(author)
        .then(data => {
            // res.send(data)
            res.redirect('getauthor')
        })
        .catch(err => {
            console.log(err.message)
            res.status(500).send({
                message: err.message || "some error occur while creating a create operation"
            })
        })
}

const getauthor = (req, res) => {
    authordb.find()
    .populate('book') 
    .exec()
    .then(authors => {
        res.render('getauthor', { authors });
    })
    .catch(err => {
        res.status(500).send({
            message: err.message || "some error occur while retrieving users"
        })
    });
};

export {author,addauthor,getauthor}