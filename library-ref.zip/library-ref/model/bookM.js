import mongoose from "mongoose";
const { Schema } = mongoose;


var schema = new mongoose.Schema({
    users: {
        type: String,
        require: true,
    }
,
    name: {
        type: String,
        require: true
    },
    author: {
        type: String,
        require: true,
    },
    date: {
        type: Date,
        require: true      
    },
    users:[{
        type : Schema.Types.ObjectId,
        ref:'Userdb'
    }]
})
const bookdb_R = mongoose.model('bookdbM_R', schema)
export default bookdb_R