import mongoose from "mongoose";
const { Schema } = mongoose;


var schema = new mongoose.Schema({
    author: {
        type: String,
        require: true
    },
    book:{
        type: String,
        require: true,
    },
    date: {
        type: String,
        require: true
    },
    book:[
        {
            type:Schema.Types.ObjectId,
            ref:'bookdb'
        }
    ],
    date:[
        {
            type:Schema.Types.ObjectId,
            ref:'bookdb'
        }
    ]
})
const authordb = mongoose.model('authordb', schema)
export {authordb};
